var searchData=
[
  ['cancelallview',['CancelAllView',['../classtencent_1_1av_1_1_a_v_room.html#a6878a1489a22c1f64ef04cef75199d1c',1,'tencent::av::AVRoom']]],
  ['changeauthority',['ChangeAuthority',['../classtencent_1_1av_1_1_a_v_room_multi.html#a48cfc88241de1c0a155802db9095e32a',1,'tencent::av::AVRoomMulti']]],
  ['clearpreviewparam',['ClearPreviewParam',['../classtencent_1_1av_1_1_a_v_support_video_preview.html#adbc9606c74863e290866da12a560074e',1,'tencent::av::AVSupportVideoPreview']]],
  ['clearselecteddevice',['ClearSelectedDevice',['../classtencent_1_1av_1_1_a_v_device_mgr.html#a0f745b37db1f255586c71d0947ded250',1,'tencent::av::AVDeviceMgr']]],
  ['config',['Config',['../structtencent_1_1av_1_1_a_v_context_1_1_config.html#ab6ac6f7fb447a939e70bbab691d22875',1,'tencent::av::AVContext::Config::Config()'],['../structtencent_1_1av_1_1_a_v_context_1_1_config.html#a45a92301a912f1e18dedc0baa09436b9',1,'tencent::av::AVContext::Config::Config(const Config &amp;other)']]],
  ['createcontext',['CreateContext',['../classtencent_1_1av_1_1_a_v_context.html#a012fed386da81537ebff20cd3d40e4d2',1,'tencent::av::AVContext']]]
];
