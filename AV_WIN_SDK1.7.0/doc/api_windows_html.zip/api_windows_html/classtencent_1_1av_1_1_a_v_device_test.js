var classtencent_1_1av_1_1_a_v_device_test =
[
    [ "DeviceOperationCallback", "classtencent_1_1av_1_1_a_v_device_test.html#a32576e53e7d1151c75bb204d1f846c95", null ],
    [ "~AVDeviceTest", "classtencent_1_1av_1_1_a_v_device_test.html#aa824820543055f59e32a69b0e365d9df", null ],
    [ "EnableDevice", "classtencent_1_1av_1_1_a_v_device_test.html#ad07cb6d38d700e84ad367e8be4f8fcd1", null ],
    [ "GetDeviceById", "classtencent_1_1av_1_1_a_v_device_test.html#a30c9c09adf5f11a859ae8d730fe28b43", null ],
    [ "GetDeviceCountByType", "classtencent_1_1av_1_1_a_v_device_test.html#a63f4071f84eabf2712fa0316ba75b8d7", null ],
    [ "GetDeviceIdListByType", "classtencent_1_1av_1_1_a_v_device_test.html#a844d366041664eba62eb91401cd99044", null ],
    [ "GetDeviceListByType", "classtencent_1_1av_1_1_a_v_device_test.html#ab7fa802763e7e27d316aec8189c70e62", null ],
    [ "GetDeviceNameListByType", "classtencent_1_1av_1_1_a_v_device_test.html#a926ce6d9734d0ba446294b4c548bb84e", null ],
    [ "SetDeviceOperationCallback", "classtencent_1_1av_1_1_a_v_device_test.html#a0c54946d05e636aaa924e1664d3b931c", null ]
];