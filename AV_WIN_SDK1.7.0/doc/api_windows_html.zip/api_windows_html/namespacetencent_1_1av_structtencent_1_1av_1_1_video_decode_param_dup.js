var namespacetencent_1_1av_structtencent_1_1av_1_1_video_decode_param_dup =
[
    [ "bitrate", "namespacetencent_1_1av.html#a8865dc20bdbbe348818387a910f24e5d", null ],
    [ "fps", "namespacetencent_1_1av.html#ae2a8dcd7baccc8ec310fa316d4c856b8", null ],
    [ "height", "namespacetencent_1_1av.html#ac1e25a2ea32d728aec17b0d330f28f5d", null ],
    [ "tiny_id", "namespacetencent_1_1av.html#a6a435b26839c92a237f162c9a39acf57", null ],
    [ "view_type", "namespacetencent_1_1av.html#af931b01eaedcba01ed2c0bba8d898026", null ],
    [ "width", "namespacetencent_1_1av.html#a815cf66aa1498c816f6dd620aba5bc8a", null ]
];