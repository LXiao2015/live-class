var structtencent_1_1av_1_1_a_v_room_1_1_info =
[
    [ "Info", "structtencent_1_1av_1_1_a_v_room_1_1_info.html#a80a249f99fef85148f2e7fdd3363a691", null ],
    [ "~Info", "structtencent_1_1av_1_1_a_v_room_1_1_info.html#a492fa08508a93d552c9596485fe6bba6", null ],
    [ "audio_category", "structtencent_1_1av_1_1_a_v_room_1_1_info.html#a6f5768e873c76df7b2593f8f2d32b517", null ],
    [ "auth_bits", "structtencent_1_1av_1_1_a_v_room_1_1_info.html#a214676d7bdc17174407fd7b88421564a", null ],
    [ "auth_buffer", "structtencent_1_1av_1_1_a_v_room_1_1_info.html#ad9d2e5ffd5e3a68662dff476c9d5bf9e", null ],
    [ "av_control_role", "structtencent_1_1av_1_1_a_v_room_1_1_info.html#ade28db6351ee956f60fd4dce537b3225", null ],
    [ "mode", "structtencent_1_1av_1_1_a_v_room_1_1_info.html#a5dd2eb8900f0b3f0c6e99d701fc4f147", null ],
    [ "peer_identifier", "structtencent_1_1av_1_1_a_v_room_1_1_info.html#a1f2651c885b0bbbf5e8e280675174a4e", null ],
    [ "relation_id", "structtencent_1_1av_1_1_a_v_room_1_1_info.html#a03d11b74e42ca9a1dff5093dc4888b30", null ],
    [ "relation_type", "structtencent_1_1av_1_1_a_v_room_1_1_info.html#a0cfa49aefcae611a256bcd7dddd98f4a", null ],
    [ "room_id", "structtencent_1_1av_1_1_a_v_room_1_1_info.html#ab54ab743c97ca10a4e14ba6eb132c64c", null ],
    [ "room_type", "structtencent_1_1av_1_1_a_v_room_1_1_info.html#af50ca918e772bb71d0c07b5c2d8ec8dd", null ]
];