var searchData=
[
  ['endpointeventid',['EndpointEventId',['../classtencent_1_1av_1_1_a_v_room.html#ac5dccf983660bdbe49d4a5dd020ff558',1,'tencent::av::AVRoom']]],
  ['error',['Error',['../namespacetencent_1_1av.html#a8a8f029f613f29439bcce0b8c4c3a5e3',1,'tencent::av']]]
];
