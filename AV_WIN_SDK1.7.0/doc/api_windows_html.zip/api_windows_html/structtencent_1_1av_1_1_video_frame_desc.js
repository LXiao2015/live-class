var structtencent_1_1av_1_1_video_frame_desc =
[
    [ "VideoFrameDesc", "structtencent_1_1av_1_1_video_frame_desc.html#a7f97a7ef8fe44ec4a1802ce9ad4d81c5", null ],
    [ "color_format", "structtencent_1_1av_1_1_video_frame_desc.html#a67c7a52ec608d4fa4daa465476a39a07", null ],
    [ "height", "structtencent_1_1av_1_1_video_frame_desc.html#a862a52c7dfc31f413cc38b8add8f0205", null ],
    [ "rotate", "structtencent_1_1av_1_1_video_frame_desc.html#ae514e815a04b38090e4423f0f8ce611c", null ],
    [ "src_type", "structtencent_1_1av_1_1_video_frame_desc.html#ae8ab5f9eb1cc241f6416164c6c8ad66d", null ],
    [ "width", "structtencent_1_1av_1_1_video_frame_desc.html#a9715ded74ac5457bdfbd043949f1bca7", null ]
];