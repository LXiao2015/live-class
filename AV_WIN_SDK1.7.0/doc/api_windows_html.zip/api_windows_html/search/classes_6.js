var searchData=
[
  ['previewparam',['PreviewParam',['../classtencent_1_1av_1_1_a_v_support_video_preview.html#structtencent_1_1av_1_1_a_v_support_video_preview_1_1_preview_param',1,'tencent::av::AVSupportVideoPreview']]]
];
