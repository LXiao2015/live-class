var searchData=
[
  ['kbps_5frecv',['kbps_recv',['../namespacetencent_1_1av.html#a5ff111d7c134688ced454acce5affc20',1,'tencent::av::NetworkStatParam']]],
  ['kbps_5fsend',['kbps_send',['../namespacetencent_1_1av.html#aaa75457a3c33e4f0f36dd53500aeebaf',1,'tencent::av::NetworkStatParam']]]
];
