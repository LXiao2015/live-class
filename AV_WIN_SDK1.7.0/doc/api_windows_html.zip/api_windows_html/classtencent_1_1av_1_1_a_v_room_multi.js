var classtencent_1_1av_1_1_a_v_room_multi =
[
    [ "Delegate", "structtencent_1_1av_1_1_a_v_room_multi_1_1_delegate.html", null ],
    [ "EnterRoomParam", "structtencent_1_1av_1_1_a_v_room_multi_1_1_enter_room_param.html", "structtencent_1_1av_1_1_a_v_room_multi_1_1_enter_room_param" ],
    [ "ChangeAuthorityCallback", "classtencent_1_1av_1_1_a_v_room_multi.html#aac5f7f3c6545742a03d11d9ba4f1d1a7", null ],
    [ "~AVRoomMulti", "classtencent_1_1av_1_1_a_v_room_multi.html#af7fff094800b402a3583c683efd63dcd", null ],
    [ "ChangeAuthority", "classtencent_1_1av_1_1_a_v_room_multi.html#a48cfc88241de1c0a155802db9095e32a", null ],
    [ "GetEndpointById", "classtencent_1_1av_1_1_a_v_room_multi.html#a369ff627b5429235dbdf915fae51b5ef", null ],
    [ "GetEndpointCount", "classtencent_1_1av_1_1_a_v_room_multi.html#a7f2b28fc9825b3b10f2c6f4b20fea37a", null ],
    [ "GetEndpointList", "classtencent_1_1av_1_1_a_v_room_multi.html#a9d8ace41eaa6945f626fd9c67d72269c", null ]
];