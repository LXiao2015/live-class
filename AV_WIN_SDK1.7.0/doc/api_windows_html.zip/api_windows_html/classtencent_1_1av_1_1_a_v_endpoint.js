var classtencent_1_1av_1_1_a_v_endpoint =
[
    [ "Info", "structtencent_1_1av_1_1_a_v_endpoint_1_1_info.html", "structtencent_1_1av_1_1_a_v_endpoint_1_1_info" ],
    [ "CancelAllViewCompleteCallback", "classtencent_1_1av_1_1_a_v_endpoint.html#a4e8441358bf150306dbdb3ef8a6d6281", null ],
    [ "RequestViewListCompleteCallback", "classtencent_1_1av_1_1_a_v_endpoint.html#aea2fe9f6ad89ba261d36c510aadf20f6", null ],
    [ "~AVEndpoint", "classtencent_1_1av_1_1_a_v_endpoint.html#a9a6ca1ee7a79ad1fcbd27b05f0b7e97d", null ],
    [ "GetId", "classtencent_1_1av_1_1_a_v_endpoint.html#af89c4fc31ec44ace78cc2ae41641eb79", null ],
    [ "GetInfo", "classtencent_1_1av_1_1_a_v_endpoint.html#aa048523a551acacfcaae0019cbac5953", null ],
    [ "HasAudio", "classtencent_1_1av_1_1_a_v_endpoint.html#a3fcc93787527251232ab30f74850bd18", null ],
    [ "HasCameraVideo", "classtencent_1_1av_1_1_a_v_endpoint.html#ac094c68c32a24378098b53a67aed3e81", null ],
    [ "HasScreenVideo", "classtencent_1_1av_1_1_a_v_endpoint.html#af1c9d3de5c9d900d0f344f5c208000d5", null ],
    [ "IsAudioMute", "classtencent_1_1av_1_1_a_v_endpoint.html#a9832889ff60e373ce8032d454b1ab333", null ],
    [ "MuteAudio", "classtencent_1_1av_1_1_a_v_endpoint.html#abccc184fc33dcb2d9dc08359f7425ce5", null ]
];