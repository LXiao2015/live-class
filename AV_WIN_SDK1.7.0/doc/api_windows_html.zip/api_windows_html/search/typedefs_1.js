var searchData=
[
  ['cancelallviewcompletecallback',['CancelAllViewCompleteCallback',['../classtencent_1_1av_1_1_a_v_endpoint.html#a4e8441358bf150306dbdb3ef8a6d6281',1,'tencent::av::AVEndpoint']]],
  ['changeauthoritycallback',['ChangeAuthorityCallback',['../classtencent_1_1av_1_1_a_v_room_multi.html#aac5f7f3c6545742a03d11d9ba4f1d1a7',1,'tencent::av::AVRoomMulti']]]
];
