var annotated =
[
    [ "tencent", "namespacetencent.html", "namespacetencent" ]
];