var structtencent_1_1av_1_1_view =
[
    [ "View", "structtencent_1_1av_1_1_view.html#a28113d987e4e1bdeab3dc7a9bea91f3b", null ],
    [ "size_type", "structtencent_1_1av_1_1_view.html#ac18f2b77831deae1bc3c5867088c5ae9", null ],
    [ "video_src_type", "structtencent_1_1av_1_1_view.html#ab44b466129abc83aa1db89e592a014e3", null ]
];