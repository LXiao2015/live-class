var searchData=
[
  ['delegate',['Delegate',['../structtencent_1_1av_1_1_a_v_room_multi_1_1_delegate.html',1,'tencent::av::AVRoomMulti']]],
  ['delegate',['Delegate',['../structtencent_1_1av_1_1_a_v_room_1_1_delegate.html',1,'tencent::av::AVRoom']]],
  ['detecteddeviceinfo',['DetectedDeviceInfo',['../namespacetencent_1_1av.html#structtencent_1_1av_1_1_detected_device_info',1,'tencent::av']]]
];
