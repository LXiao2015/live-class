var namespacetencent_1_1av_structtencent_1_1av_1_1_video_encode_param_dup =
[
    [ "bitrate", "namespacetencent_1_1av.html#ad9db0e06a70dc832616422ec143dd09b", null ],
    [ "fps", "namespacetencent_1_1av.html#ae965ed94022f6cd2eb787c3d7180a2cf", null ],
    [ "height", "namespacetencent_1_1av.html#a4a952588c6463cf8673b5e4907103689", null ],
    [ "view_type", "namespacetencent_1_1av.html#a993ceb389711655930286b762b64a39e", null ],
    [ "width", "namespacetencent_1_1av.html#a7d3dd20e83a52c07f667c9f5af9b59f8", null ]
];