var namespacetencent_1_1av_structtencent_1_1av_1_1_room_stat_param_dup =
[
    [ "audio_param", "namespacetencent_1_1av.html#a366219b81b89a9bb76b40513003b611e", null ],
    [ "network_param", "namespacetencent_1_1av.html#aa8a29fb9eb561a03373846fd9a4a4c13", null ],
    [ "tick_count_begin", "namespacetencent_1_1av.html#a9dc99282492896ceab49ac65bbea8e8d", null ],
    [ "tick_count_end", "namespacetencent_1_1av.html#a0047e71cd2e68a0aa86beefc92619ba6", null ],
    [ "video_param", "namespacetencent_1_1av.html#a568ef391cc4ba8aa60a94673642f22ff", null ]
];