var searchData=
[
  ['identifier',['identifier',['../structtencent_1_1av_1_1_audio_frame.html#a973c9faddad6f838a34a86414ab59555',1,'tencent::av::AudioFrame::identifier()'],['../structtencent_1_1av_1_1_video_frame.html#a0b172e6ba0751512678ed33734ad9a24',1,'tencent::av::VideoFrame::identifier()'],['../structtencent_1_1av_1_1_a_v_context_1_1_config.html#aa585d75dab383a4e726a17dcb35f5b06',1,'tencent::av::AVContext::Config::identifier()'],['../structtencent_1_1av_1_1_a_v_endpoint_1_1_info.html#a216fe1e010e9dff40c3b74ba701f3536',1,'tencent::av::AVEndpoint::Info::identifier()']]],
  ['is_5fmute',['is_mute',['../structtencent_1_1av_1_1_a_v_endpoint_1_1_info.html#acb3045d39d905bb76f4ac470b7644a04',1,'tencent::av::AVEndpoint::Info']]],
  ['isnewdevice',['isNewDevice',['../namespacetencent_1_1av.html#a3e739b0b35c41da7a97090bc7110ee50',1,'tencent::av::DetectedDeviceInfo']]],
  ['isuseddevice',['isUsedDevice',['../namespacetencent_1_1av.html#a8cb0233315bf52adef8ab46b26c29233',1,'tencent::av::DetectedDeviceInfo']]]
];
