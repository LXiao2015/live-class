var searchData=
[
  ['registaudiodatacallback',['RegistAudioDataCallback',['../classtencent_1_1av_1_1_a_v_audio_ctrl.html#af1666ad99f0f4fb52a005a76c2b36090',1,'tencent::av::AVAudioCtrl']]],
  ['requestviewlist',['RequestViewList',['../classtencent_1_1av_1_1_a_v_room.html#a719a2d13030dfad67634ac3954223031',1,'tencent::av::AVRoom']]]
];
