var searchData=
[
  ['sample_5frate',['sample_rate',['../structtencent_1_1av_1_1_audio_frame_desc.html#af253a3182f15c0f47f9bce8e27318e4a',1,'tencent::av::AudioFrameDesc::sample_rate()'],['../namespacetencent_1_1av.html#a0eef0bb084a71e712a94251f179efee3',1,'tencent::av::AudioQosParam::sample_rate()']]],
  ['sdk_5fapp_5fid',['sdk_app_id',['../structtencent_1_1av_1_1_a_v_context_1_1_config.html#af91d7b81848921b5599988f17d3da8cb',1,'tencent::av::AVContext::Config']]],
  ['sdk_5fversion',['sdk_version',['../structtencent_1_1av_1_1_a_v_endpoint_1_1_info.html#a77567aea2c2179c1da35d6c9e0988c40',1,'tencent::av::AVEndpoint::Info']]],
  ['size_5ftype',['size_type',['../structtencent_1_1av_1_1_view.html#ac18f2b77831deae1bc3c5867088c5ae9',1,'tencent::av::View']]],
  ['src_5ftype',['src_type',['../structtencent_1_1av_1_1_audio_frame_desc.html#a2a5fcfb0f4ada2c16aa63ea4fa09dfda',1,'tencent::av::AudioFrameDesc::src_type()'],['../structtencent_1_1av_1_1_video_frame_desc.html#ae8ab5f9eb1cc241f6416164c6c8ad66d',1,'tencent::av::VideoFrameDesc::src_type()'],['../classtencent_1_1av_1_1_a_v_support_video_preview.html#a0d470f61f67d0e786dca83f327358255',1,'tencent::av::AVSupportVideoPreview::PreviewParam::src_type()']]],
  ['strguid',['strGuid',['../namespacetencent_1_1av.html#a80462fb428a1ae7ef120c05407da9807',1,'tencent::av::DetectedDeviceInfo']]],
  ['string_5fid',['string_id',['../structtencent_1_1av_1_1_a_v_device_1_1_info.html#afc55903aa3f6ea9c06c03eba6b34f297',1,'tencent::av::AVDevice::Info']]],
  ['strname',['strName',['../namespacetencent_1_1av.html#ae82c7b1b7679879ebe58b596f5e156d3',1,'tencent::av::DetectedDeviceInfo']]]
];
