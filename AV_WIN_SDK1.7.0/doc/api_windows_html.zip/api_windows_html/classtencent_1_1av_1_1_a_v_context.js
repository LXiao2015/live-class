var classtencent_1_1av_1_1_a_v_context =
[
    [ "Config", "structtencent_1_1av_1_1_a_v_context_1_1_config.html", "structtencent_1_1av_1_1_a_v_context_1_1_config" ],
    [ "StartCompleteCallback", "classtencent_1_1av_1_1_a_v_context.html#a02d48719fb3495af6a0d345eb7045239", null ],
    [ "~AVContext", "classtencent_1_1av_1_1_a_v_context.html#a3ca7bdd23e53471df5a05526e23b964c", null ],
    [ "EnterRoom", "classtencent_1_1av_1_1_a_v_context.html#a41dff00ab829138edb5496f6a209f558", null ],
    [ "ExitRoom", "classtencent_1_1av_1_1_a_v_context.html#a4dbefa03827874872d074206c39282f7", null ],
    [ "GetAudioCtrl", "classtencent_1_1av_1_1_a_v_context.html#a910ffe1886c210d90ce32caeeb9fed7d", null ],
    [ "GetAudioDeviceMgr", "classtencent_1_1av_1_1_a_v_context.html#ad010fb9969919afae9e20a089e1f260f", null ],
    [ "GetDeviceTest", "classtencent_1_1av_1_1_a_v_context.html#a4bc68d92d4a2f42d75795dd83dd9a3b4", null ],
    [ "GetRoom", "classtencent_1_1av_1_1_a_v_context.html#abba60ce250795f8271b635277d36b75c", null ],
    [ "GetVideoCtrl", "classtencent_1_1av_1_1_a_v_context.html#a12b488959c83a9b4e1a5fbcc9eaa5e96", null ],
    [ "GetVideoDeviceMgr", "classtencent_1_1av_1_1_a_v_context.html#a077dc940c37161715d29c68cfe9bfab6", null ],
    [ "StartContext", "classtencent_1_1av_1_1_a_v_context.html#ae5d4f3b56d8ac768ab2932041ef4450d", null ],
    [ "StartDeviceTest", "classtencent_1_1av_1_1_a_v_context.html#abf2be7e186aed60106781dd5456a9eb9", null ],
    [ "StopContext", "classtencent_1_1av_1_1_a_v_context.html#ae87affbe5f15b870bd0a31282f23d6a4", null ],
    [ "StopDeviceTest", "classtencent_1_1av_1_1_a_v_context.html#a8d8a2f788dc7c2cb7253ac01bbd995b1", null ]
];