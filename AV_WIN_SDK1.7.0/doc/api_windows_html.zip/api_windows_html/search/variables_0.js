var searchData=
[
  ['account_5ftype',['account_type',['../structtencent_1_1av_1_1_a_v_context_1_1_config.html#ad6805bbfc8f540d67526df9066dda8c7',1,'tencent::av::AVContext::Config']]],
  ['app_5fid_5fat3rd',['app_id_at3rd',['../structtencent_1_1av_1_1_a_v_context_1_1_config.html#a5cbb8182b3299a77ecfd6a0295cef888',1,'tencent::av::AVContext::Config']]],
  ['app_5froom_5fid',['app_room_id',['../structtencent_1_1av_1_1_a_v_room_multi_1_1_enter_room_param.html#ac592fc01210e184cf564d80366c17708',1,'tencent::av::AVRoomMulti::EnterRoomParam']]],
  ['audio_5fcategory',['audio_category',['../structtencent_1_1av_1_1_a_v_room_1_1_info.html#a6f5768e873c76df7b2593f8f2d32b517',1,'tencent::av::AVRoom::Info::audio_category()'],['../structtencent_1_1av_1_1_a_v_room_multi_1_1_enter_room_param.html#aad125ea61b97087b85837ad682c3831d',1,'tencent::av::AVRoomMulti::EnterRoomParam::audio_category()']]],
  ['audio_5fparam',['audio_param',['../namespacetencent_1_1av.html#a366219b81b89a9bb76b40513003b611e',1,'tencent::av::RoomStatParam']]],
  ['auth_5fbits',['auth_bits',['../structtencent_1_1av_1_1_a_v_room_1_1_info.html#a214676d7bdc17174407fd7b88421564a',1,'tencent::av::AVRoom::Info::auth_bits()'],['../structtencent_1_1av_1_1_a_v_room_multi_1_1_enter_room_param.html#a274827efe7c3795fea8e258a3e7c444c',1,'tencent::av::AVRoomMulti::EnterRoomParam::auth_bits()']]],
  ['auth_5fbuffer',['auth_buffer',['../structtencent_1_1av_1_1_a_v_room_1_1_info.html#ad9d2e5ffd5e3a68662dff476c9d5bf9e',1,'tencent::av::AVRoom::Info::auth_buffer()'],['../structtencent_1_1av_1_1_a_v_room_multi_1_1_enter_room_param.html#a292f632ea2e85a3968f07f104423dbba',1,'tencent::av::AVRoomMulti::EnterRoomParam::auth_buffer()']]],
  ['auto_5fcreate_5froom',['auto_create_room',['../structtencent_1_1av_1_1_a_v_room_multi_1_1_enter_room_param.html#ac72d619366e48c1aaa9fd1dea2c5ab88',1,'tencent::av::AVRoomMulti::EnterRoomParam']]],
  ['av_5fcontrol_5frole',['av_control_role',['../structtencent_1_1av_1_1_a_v_room_1_1_info.html#ade28db6351ee956f60fd4dce537b3225',1,'tencent::av::AVRoom::Info::av_control_role()'],['../structtencent_1_1av_1_1_a_v_room_multi_1_1_enter_room_param.html#afd6aba9eaf8e8e51d6c808a91c52b6b6',1,'tencent::av::AVRoomMulti::EnterRoomParam::av_control_role()']]]
];
