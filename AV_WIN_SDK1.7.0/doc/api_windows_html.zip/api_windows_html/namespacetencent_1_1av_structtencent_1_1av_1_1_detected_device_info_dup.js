var namespacetencent_1_1av_structtencent_1_1av_1_1_detected_device_info_dup =
[
    [ "flow", "namespacetencent_1_1av.html#a12cc6535f005199f473994e7ae31a054", null ],
    [ "isNewDevice", "namespacetencent_1_1av.html#a3e739b0b35c41da7a97090bc7110ee50", null ],
    [ "isUsedDevice", "namespacetencent_1_1av.html#a8cb0233315bf52adef8ab46b26c29233", null ],
    [ "strGuid", "namespacetencent_1_1av.html#a80462fb428a1ae7ef120c05407da9807", null ],
    [ "strName", "namespacetencent_1_1av.html#ae82c7b1b7679879ebe58b596f5e156d3", null ]
];