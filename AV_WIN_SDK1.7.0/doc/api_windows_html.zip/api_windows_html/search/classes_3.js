var searchData=
[
  ['enterroomparam',['EnterRoomParam',['../structtencent_1_1av_1_1_a_v_room_1_1_enter_room_param.html',1,'tencent::av::AVRoom']]],
  ['enterroomparam',['EnterRoomParam',['../structtencent_1_1av_1_1_a_v_room_multi_1_1_enter_room_param.html',1,'tencent::av::AVRoomMulti']]]
];
