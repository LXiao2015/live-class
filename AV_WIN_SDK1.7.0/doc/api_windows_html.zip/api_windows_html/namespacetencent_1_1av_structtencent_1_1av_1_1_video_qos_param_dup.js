var namespacetencent_1_1av_structtencent_1_1av_1_1_video_qos_param_dup =
[
    [ "bitrate", "namespacetencent_1_1av.html#a664d9db016d8d4c9c46c243d3954c7ec", null ],
    [ "fps", "namespacetencent_1_1av.html#ac2d5c559596a2b55b9dcae722af1d6b0", null ],
    [ "height", "namespacetencent_1_1av.html#a88215cc241aa643b87f877cbf3b8faf7", null ],
    [ "width", "namespacetencent_1_1av.html#a84191f804e836a2e942b965f5f3da980", null ]
];