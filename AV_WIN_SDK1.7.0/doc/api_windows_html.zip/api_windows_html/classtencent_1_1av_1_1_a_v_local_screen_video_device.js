var classtencent_1_1av_1_1_a_v_local_screen_video_device =
[
    [ "EnableHDMode", "classtencent_1_1av_1_1_a_v_local_screen_video_device.html#a85ce22ca6c8fda6b2bb1eb1becf82f2f", null ],
    [ "GetScreenCaptureParam", "classtencent_1_1av_1_1_a_v_local_screen_video_device.html#a7f2e92c070e662426778ed9943ce8632", null ],
    [ "SetScreenCaptureParam", "classtencent_1_1av_1_1_a_v_local_screen_video_device.html#a1e44244e6f35074a3b844f93a8ded54a", null ]
];