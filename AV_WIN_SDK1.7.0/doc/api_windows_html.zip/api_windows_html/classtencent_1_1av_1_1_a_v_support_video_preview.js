var classtencent_1_1av_1_1_a_v_support_video_preview =
[
    [ "PreviewParam", "classtencent_1_1av_1_1_a_v_support_video_preview.html#structtencent_1_1av_1_1_a_v_support_video_preview_1_1_preview_param", [
      [ "color_format", "classtencent_1_1av_1_1_a_v_support_video_preview.html#a94e2c9f3be7d9ab84c337fef6bda05ff", null ],
      [ "device_id", "classtencent_1_1av_1_1_a_v_support_video_preview.html#ad5a6a7e5d1dd5bebf835ede07f68eeb7", null ],
      [ "height", "classtencent_1_1av_1_1_a_v_support_video_preview.html#aee3e192c5ea34f78c57e2ec106ad3f6c", null ],
      [ "src_type", "classtencent_1_1av_1_1_a_v_support_video_preview.html#a0d470f61f67d0e786dca83f327358255", null ],
      [ "width", "classtencent_1_1av_1_1_a_v_support_video_preview.html#a0a5c07e9657a8a875a0e4246fb318a52", null ]
    ] ],
    [ "PreviewCallback", "classtencent_1_1av_1_1_a_v_support_video_preview.html#aa0b74f3773d6da90c6a88b3efd7fb146", null ],
    [ "ClearPreviewParam", "classtencent_1_1av_1_1_a_v_support_video_preview.html#adbc9606c74863e290866da12a560074e", null ],
    [ "GetPreviewCallback", "classtencent_1_1av_1_1_a_v_support_video_preview.html#a71bb12e4e05bbcdf38b2d3ddb58cf018", null ],
    [ "GetPreviewCustomData", "classtencent_1_1av_1_1_a_v_support_video_preview.html#a4a18300f6862167d0c54c9517cd07d84", null ],
    [ "SetPreviewCallback", "classtencent_1_1av_1_1_a_v_support_video_preview.html#ab4e7dca91b4fa41dd9eddc69e18b5aaf", null ],
    [ "SetPreviewParam", "classtencent_1_1av_1_1_a_v_support_video_preview.html#a523a5ceb88c96ffd40742bd28ce693af", null ]
];