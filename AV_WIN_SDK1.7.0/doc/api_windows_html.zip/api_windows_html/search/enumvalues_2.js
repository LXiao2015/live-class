var searchData=
[
  ['detect_5fmic',['Detect_Mic',['../namespacetencent_1_1av.html#ae7f6c5cac42229320a6559e8b2f0f8f3aa29d39079970c4ec7154be1cb68a0f93',1,'tencent::av']]],
  ['detect_5fspeaker',['Detect_Speaker',['../namespacetencent_1_1av.html#ae7f6c5cac42229320a6559e8b2f0f8f3a2ae0f18da18d7269f281bbcc87cbf8f5',1,'tencent::av']]],
  ['device_5foperation_5fclose',['DEVICE_OPERATION_CLOSE',['../classtencent_1_1av_1_1_a_v_device.html#a30defa389bbe29242605d46c80601d01a1366fe6ecfd3be8e538f6e7935be8cfe',1,'tencent::av::AVDevice']]],
  ['device_5foperation_5fopen',['DEVICE_OPERATION_OPEN',['../classtencent_1_1av_1_1_a_v_device.html#a30defa389bbe29242605d46c80601d01a5eb23c286a27ec9863a272b836a971b3',1,'tencent::av::AVDevice']]],
  ['device_5foperation_5funknown',['DEVICE_OPERATION_UNKNOWN',['../classtencent_1_1av_1_1_a_v_device.html#a30defa389bbe29242605d46c80601d01ab6c7ac2fd654fbbae32ca29582e64a40',1,'tencent::av::AVDevice']]]
];
