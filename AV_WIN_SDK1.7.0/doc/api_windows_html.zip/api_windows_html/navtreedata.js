var NAVTREE =
[
  [ "音视频通讯SDK API参考手册", "index.html", [
    [ "命名空间成员", "namespacemembers.html", [
      [ "全部", "namespacemembers.html", null ],
      [ "类型定义", "namespacemembers_type.html", null ],
      [ "枚举", "namespacemembers_enum.html", null ],
      [ "枚举值", "namespacemembers_eval.html", null ]
    ] ],
    [ "类", null, [
      [ "类列表", "annotated.html", "annotated" ],
      [ "类索引", "classes.html", null ],
      [ "类继承关系", "hierarchy.html", "hierarchy" ],
      [ "类成员", "functions.html", [
        [ "全部", "functions.html", "functions_dup" ],
        [ "函数", "functions_func.html", null ],
        [ "变量", "functions_vars.html", null ],
        [ "类型定义", "functions_type.html", null ],
        [ "枚举", "functions_enum.html", null ],
        [ "枚举值", "functions_eval.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html",
"structtencent_1_1av_1_1_a_v_device_1_1_info.html#afc55903aa3f6ea9c06c03eba6b34f297"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';