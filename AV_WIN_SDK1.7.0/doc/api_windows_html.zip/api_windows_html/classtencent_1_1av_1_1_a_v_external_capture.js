var classtencent_1_1av_1_1_a_v_external_capture =
[
    [ "OnCaptureFrame", "classtencent_1_1av_1_1_a_v_external_capture.html#ad1af57c9553a9226409dae3ee095fc1a", null ]
];