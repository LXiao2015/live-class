var searchData=
[
  ['detecteddevicetype',['DetectedDeviceType',['../namespacetencent_1_1av.html#ae7f6c5cac42229320a6559e8b2f0f8f3',1,'tencent::av']]],
  ['deviceoperation',['DeviceOperation',['../classtencent_1_1av_1_1_a_v_device.html#a30defa389bbe29242605d46c80601d01',1,'tencent::av::AVDevice']]]
];
