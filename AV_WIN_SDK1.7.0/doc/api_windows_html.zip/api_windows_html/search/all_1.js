var searchData=
[
  ['bitrate',['bitrate',['../namespacetencent_1_1av.html#ad9db0e06a70dc832616422ec143dd09b',1,'tencent::av::VideoEncodeParam::bitrate()'],['../namespacetencent_1_1av.html#a8865dc20bdbbe348818387a910f24e5d',1,'tencent::av::VideoDecodeParam::bitrate()'],['../namespacetencent_1_1av.html#a664d9db016d8d4c9c46c243d3954c7ec',1,'tencent::av::VideoQosParam::bitrate()'],['../namespacetencent_1_1av.html#a1c84fd8b1ca2b678b0328c45000f1860',1,'tencent::av::AudioQosParam::bitrate()']]],
  ['bits',['bits',['../structtencent_1_1av_1_1_audio_frame_desc.html#a725cd18cf89834985b836437da543648',1,'tencent::av::AudioFrameDesc']]]
];
