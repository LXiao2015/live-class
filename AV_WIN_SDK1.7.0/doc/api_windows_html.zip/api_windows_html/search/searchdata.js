var indexSectionsWithContent =
{
  0: "abcdefghiklmnopqrstuvw~",
  1: "acdeinprv",
  2: "t",
  3: "acdeghimorsuv~",
  4: "abcdefhiklmnpqrstvw",
  5: "acdfoprsv",
  6: "acdemnrsv",
  7: "acdemnrv"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues"
};

var indexSectionLabels =
{
  0: "全部",
  1: "类",
  2: "命名空间",
  3: "函数",
  4: "变量",
  5: "类型定义",
  6: "枚举",
  7: "枚举值"
};

