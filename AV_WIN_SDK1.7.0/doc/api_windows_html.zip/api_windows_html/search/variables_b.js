var searchData=
[
  ['name',['name',['../structtencent_1_1av_1_1_a_v_device_1_1_info.html#a95238ef54839617a7f37be5c52435379',1,'tencent::av::AVDevice::Info']]],
  ['network_5fparam',['network_param',['../namespacetencent_1_1av.html#aa8a29fb9eb561a03373846fd9a4a4c13',1,'tencent::av::RoomStatParam']]]
];
