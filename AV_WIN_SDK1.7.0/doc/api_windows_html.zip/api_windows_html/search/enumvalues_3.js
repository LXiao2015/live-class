var searchData=
[
  ['event_5fid_5fendpoint_5fenter',['EVENT_ID_ENDPOINT_ENTER',['../classtencent_1_1av_1_1_a_v_room.html#ac5dccf983660bdbe49d4a5dd020ff558acc1882018047c3c7a047869dc0d9d9a8',1,'tencent::av::AVRoom']]],
  ['event_5fid_5fendpoint_5fexit',['EVENT_ID_ENDPOINT_EXIT',['../classtencent_1_1av_1_1_a_v_room.html#ac5dccf983660bdbe49d4a5dd020ff558a33672213e957551258eead00acfdfdca',1,'tencent::av::AVRoom']]],
  ['event_5fid_5fendpoint_5fhas_5faudio',['EVENT_ID_ENDPOINT_HAS_AUDIO',['../classtencent_1_1av_1_1_a_v_room.html#ac5dccf983660bdbe49d4a5dd020ff558a75ec0b37b35903132c8a3db3f9eda069',1,'tencent::av::AVRoom']]],
  ['event_5fid_5fendpoint_5fhas_5fcamera_5fvideo',['EVENT_ID_ENDPOINT_HAS_CAMERA_VIDEO',['../classtencent_1_1av_1_1_a_v_room.html#ac5dccf983660bdbe49d4a5dd020ff558ac3d2202d4b91d561dab68d924bc71f64',1,'tencent::av::AVRoom']]],
  ['event_5fid_5fendpoint_5fhas_5fscreen_5fvideo',['EVENT_ID_ENDPOINT_HAS_SCREEN_VIDEO',['../classtencent_1_1av_1_1_a_v_room.html#ac5dccf983660bdbe49d4a5dd020ff558a2c3146bfa6a00ff61b07b22343dc8e0e',1,'tencent::av::AVRoom']]],
  ['event_5fid_5fendpoint_5fno_5faudio',['EVENT_ID_ENDPOINT_NO_AUDIO',['../classtencent_1_1av_1_1_a_v_room.html#ac5dccf983660bdbe49d4a5dd020ff558a39ecaee86280913436a62dc6d223ac61',1,'tencent::av::AVRoom']]],
  ['event_5fid_5fendpoint_5fno_5fcamera_5fvideo',['EVENT_ID_ENDPOINT_NO_CAMERA_VIDEO',['../classtencent_1_1av_1_1_a_v_room.html#ac5dccf983660bdbe49d4a5dd020ff558acac09f84b434e29c484a6df4252462ac',1,'tencent::av::AVRoom']]],
  ['event_5fid_5fendpoint_5fno_5fscreen_5fvideo',['EVENT_ID_ENDPOINT_NO_SCREEN_VIDEO',['../classtencent_1_1av_1_1_a_v_room.html#ac5dccf983660bdbe49d4a5dd020ff558a143ff22ff3bab8ddd159279313055a3c',1,'tencent::av::AVRoom']]],
  ['event_5fid_5fnone',['EVENT_ID_NONE',['../classtencent_1_1av_1_1_a_v_room.html#ac5dccf983660bdbe49d4a5dd020ff558aba3d1be7202d4b618230af0b49bd2ac8',1,'tencent::av::AVRoom']]]
];
