var searchData=
[
  ['relation_5ftype_5fbuddy',['RELATION_TYPE_BUDDY',['../namespacetencent_1_1av.html#acec14806701ac8bb8c60f6daa6434c26a8680d1d73df92c4e0e303ee3db053a01',1,'tencent::av']]],
  ['relation_5ftype_5fdiscuss',['RELATION_TYPE_DISCUSS',['../namespacetencent_1_1av.html#acec14806701ac8bb8c60f6daa6434c26ad5a425ef972e2fcbce949b443d7bc50f',1,'tencent::av']]],
  ['relation_5ftype_5fgroup',['RELATION_TYPE_GROUP',['../namespacetencent_1_1av.html#acec14806701ac8bb8c60f6daa6434c26a46d789167bfed417e29094ba21a8d892',1,'tencent::av']]],
  ['relation_5ftype_5fopensdk',['RELATION_TYPE_OPENSDK',['../namespacetencent_1_1av.html#acec14806701ac8bb8c60f6daa6434c26a441d9b55ce463828eb429bf826c78e69',1,'tencent::av']]],
  ['relation_5ftype_5ftemp',['RELATION_TYPE_TEMP',['../namespacetencent_1_1av.html#acec14806701ac8bb8c60f6daa6434c26a957128769b8f316567fbb6f66df76d8a',1,'tencent::av']]],
  ['relation_5ftype_5funknown',['RELATION_TYPE_UNKNOWN',['../namespacetencent_1_1av.html#acec14806701ac8bb8c60f6daa6434c26ab62b75d805dff4b9a21f2c26ccb75221',1,'tencent::av']]],
  ['room_5ftype_5fmulti',['ROOM_TYPE_MULTI',['../classtencent_1_1av_1_1_a_v_room.html#a7656ec1015b94f3f34dc3786af057e86aea1b4c4bb59ba0ab35a84a91b057df6a',1,'tencent::av::AVRoom']]],
  ['room_5ftype_5fnone',['ROOM_TYPE_NONE',['../classtencent_1_1av_1_1_a_v_room.html#a7656ec1015b94f3f34dc3786af057e86a67934e6d79a9d12b1ebc582101a29ecc',1,'tencent::av::AVRoom']]],
  ['room_5ftype_5fpair',['ROOM_TYPE_PAIR',['../classtencent_1_1av_1_1_a_v_room.html#a7656ec1015b94f3f34dc3786af057e86aeff056618554b1773c5f8411688d8f32',1,'tencent::av::AVRoom']]]
];
