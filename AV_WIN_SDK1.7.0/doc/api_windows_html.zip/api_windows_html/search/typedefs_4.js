var searchData=
[
  ['ondevivedetectnotify',['OnDeviveDetectNotify',['../classtencent_1_1av_1_1_a_v_device_mgr.html#a75e48b8730d536125250c22224584b51',1,'tencent::av::AVDeviceMgr']]]
];
