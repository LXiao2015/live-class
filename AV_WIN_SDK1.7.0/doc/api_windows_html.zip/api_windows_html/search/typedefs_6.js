var searchData=
[
  ['requestviewlistcompletecallback',['RequestViewListCompleteCallback',['../classtencent_1_1av_1_1_a_v_endpoint.html#aea2fe9f6ad89ba261d36c510aadf20f6',1,'tencent::av::AVEndpoint']]]
];
