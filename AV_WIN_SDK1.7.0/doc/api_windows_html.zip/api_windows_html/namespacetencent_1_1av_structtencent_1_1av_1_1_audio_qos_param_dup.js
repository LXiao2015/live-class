var namespacetencent_1_1av_structtencent_1_1av_1_1_audio_qos_param_dup =
[
    [ "bitrate", "namespacetencent_1_1av.html#a1c84fd8b1ca2b678b0328c45000f1860", null ],
    [ "channel_count", "namespacetencent_1_1av.html#acc3dd9a73f0244397c4a02120ebc5e08", null ],
    [ "codec_type", "namespacetencent_1_1av.html#a1899649e7779565102bdfab1dd0779c9", null ],
    [ "sample_rate", "namespacetencent_1_1av.html#a0eef0bb084a71e712a94251f179efee3", null ]
];