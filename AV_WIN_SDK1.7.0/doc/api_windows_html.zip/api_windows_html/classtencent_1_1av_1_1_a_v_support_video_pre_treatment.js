var classtencent_1_1av_1_1_a_v_support_video_pre_treatment =
[
    [ "PreTreatmentFun", "classtencent_1_1av_1_1_a_v_support_video_pre_treatment.html#a1d5c1ad89b75055318dea82e6c584596", null ],
    [ "SetPreTreatmentFun", "classtencent_1_1av_1_1_a_v_support_video_pre_treatment.html#a7d0b17a62e0b4a445162e8845bdd93a5", null ]
];