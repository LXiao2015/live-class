var namespacetencent_1_1av_structtencent_1_1av_1_1_camera_info_dup =
[
    [ "device_id", "namespacetencent_1_1av.html#a4365829807b2466d8845fee5b89bb03d", null ],
    [ "fps", "namespacetencent_1_1av.html#a4c983b88d0bdac4550b64c4f48f22bc2", null ],
    [ "height", "namespacetencent_1_1av.html#a4461beed443bdc4638e593fe824bd954", null ],
    [ "width", "namespacetencent_1_1av.html#a7a9ea5dd87190cd3ceea7571bcf6eb41", null ]
];