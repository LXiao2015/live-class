var searchData=
[
  ['loss_5fmodel_5frecv',['loss_model_recv',['../namespacetencent_1_1av.html#a0d01d7c7404b19af0fa92856cda77920',1,'tencent::av::NetworkStatParam']]],
  ['loss_5fmodel_5fsend',['loss_model_send',['../namespacetencent_1_1av.html#ae10e765484ceac763817a90b96ddc136',1,'tencent::av::NetworkStatParam']]],
  ['loss_5frate_5frecv',['loss_rate_recv',['../namespacetencent_1_1av.html#abc13d02dc48625fd53d292502f272cc1',1,'tencent::av::NetworkStatParam']]],
  ['loss_5frate_5fsend',['loss_rate_send',['../namespacetencent_1_1av.html#a23bb0a5ab57a9abfdd25d0379fb3681a',1,'tencent::av::NetworkStatParam']]]
];
