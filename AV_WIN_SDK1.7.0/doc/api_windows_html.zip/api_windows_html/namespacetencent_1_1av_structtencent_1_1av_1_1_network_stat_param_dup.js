var namespacetencent_1_1av_structtencent_1_1av_1_1_network_stat_param_dup =
[
    [ "cpu_rate_app", "namespacetencent_1_1av.html#aee1f10604c356bc8268d8253de30ae87", null ],
    [ "cpu_rate_sys", "namespacetencent_1_1av.html#acf9930c64f033fdadb2e236e989182e3", null ],
    [ "kbps_recv", "namespacetencent_1_1av.html#a5ff111d7c134688ced454acce5affc20", null ],
    [ "kbps_send", "namespacetencent_1_1av.html#aaa75457a3c33e4f0f36dd53500aeebaf", null ],
    [ "loss_model_recv", "namespacetencent_1_1av.html#a0d01d7c7404b19af0fa92856cda77920", null ],
    [ "loss_model_send", "namespacetencent_1_1av.html#ae10e765484ceac763817a90b96ddc136", null ],
    [ "loss_rate_recv", "namespacetencent_1_1av.html#abc13d02dc48625fd53d292502f272cc1", null ],
    [ "loss_rate_send", "namespacetencent_1_1av.html#a23bb0a5ab57a9abfdd25d0379fb3681a", null ],
    [ "packet_recv", "namespacetencent_1_1av.html#a986ce7d20de5c34ef3697302b3d9b6f3", null ],
    [ "packet_send", "namespacetencent_1_1av.html#a251fec1526068c2c38198ef31794fa47", null ],
    [ "rtt", "namespacetencent_1_1av.html#af415c066ff877d881a12a460d30497d0", null ]
];