var searchData=
[
  ['audiodatacallback',['AudioDataCallback',['../classtencent_1_1av_1_1_a_v_audio_ctrl.html#a623bebe3b43e06b713cdb4db9b19c44a',1,'tencent::av::AVAudioCtrl']]],
  ['avclosure',['AVClosure',['../namespacetencent_1_1av.html#a455fac4d6fbb386ce1270016a11dcc20',1,'tencent::av']]]
];
