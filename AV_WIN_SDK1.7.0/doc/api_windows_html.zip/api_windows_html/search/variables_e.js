var searchData=
[
  ['relation_5fid',['relation_id',['../structtencent_1_1av_1_1_a_v_room_1_1_info.html#a03d11b74e42ca9a1dff5093dc4888b30',1,'tencent::av::AVRoom::Info']]],
  ['relation_5ftype',['relation_type',['../structtencent_1_1av_1_1_a_v_room_1_1_info.html#a0cfa49aefcae611a256bcd7dddd98f4a',1,'tencent::av::AVRoom::Info']]],
  ['room_5fid',['room_id',['../structtencent_1_1av_1_1_a_v_room_1_1_info.html#ab54ab743c97ca10a4e14ba6eb132c64c',1,'tencent::av::AVRoom::Info']]],
  ['room_5ftype',['room_type',['../structtencent_1_1av_1_1_a_v_room_1_1_enter_room_param.html#afa870b8255d63fdf818d8a537a1954dc',1,'tencent::av::AVRoom::EnterRoomParam::room_type()'],['../structtencent_1_1av_1_1_a_v_room_1_1_info.html#af50ca918e772bb71d0c07b5c2d8ec8dd',1,'tencent::av::AVRoom::Info::room_type()']]],
  ['rotate',['rotate',['../structtencent_1_1av_1_1_video_frame_desc.html#ae514e815a04b38090e4423f0f8ce611c',1,'tencent::av::VideoFrameDesc']]],
  ['rtt',['rtt',['../namespacetencent_1_1av.html#af415c066ff877d881a12a460d30497d0',1,'tencent::av::NetworkStatParam']]]
];
