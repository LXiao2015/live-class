var classtencent_1_1av_1_1_a_v_device =
[
    [ "Info", "structtencent_1_1av_1_1_a_v_device_1_1_info.html", "structtencent_1_1av_1_1_a_v_device_1_1_info" ],
    [ "DeviceOperation", "classtencent_1_1av_1_1_a_v_device.html#a30defa389bbe29242605d46c80601d01", [
      [ "DEVICE_OPERATION_UNKNOWN", "classtencent_1_1av_1_1_a_v_device.html#a30defa389bbe29242605d46c80601d01ab6c7ac2fd654fbbae32ca29582e64a40", null ],
      [ "DEVICE_OPERATION_OPEN", "classtencent_1_1av_1_1_a_v_device.html#a30defa389bbe29242605d46c80601d01a5eb23c286a27ec9863a272b836a971b3", null ],
      [ "DEVICE_OPERATION_CLOSE", "classtencent_1_1av_1_1_a_v_device.html#a30defa389bbe29242605d46c80601d01a1366fe6ecfd3be8e538f6e7935be8cfe", null ]
    ] ],
    [ "GetId", "classtencent_1_1av_1_1_a_v_device.html#ae94780e1966fe1790ca743533b0285a1", null ],
    [ "GetInfo", "classtencent_1_1av_1_1_a_v_device.html#ad2c87bdbc797fb9b1d1335a6e1389629", null ],
    [ "GetType", "classtencent_1_1av_1_1_a_v_device.html#a434287ef7a63084ff9da1637149e88ed", null ],
    [ "IsSelected", "classtencent_1_1av_1_1_a_v_device.html#af3fcedceae73c3325c60bcf0c00bab40", null ],
    [ "SetInfo", "classtencent_1_1av_1_1_a_v_device.html#a11d4fff2bbf7c46fbb9136b55674388c", null ],
    [ "SetSelect", "classtencent_1_1av_1_1_a_v_device.html#a12133a05135c739f2f735cdc0a0ebb6d", null ]
];