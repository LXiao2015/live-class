var searchData=
[
  ['data',['data',['../structtencent_1_1av_1_1_audio_frame.html#a7bac65e6cc7bbb07850610906f65578a',1,'tencent::av::AudioFrame::data()'],['../structtencent_1_1av_1_1_video_frame.html#a317c4b2b6627e49f52b891a9809c4b51',1,'tencent::av::VideoFrame::data()']]],
  ['data_5fsize',['data_size',['../structtencent_1_1av_1_1_audio_frame.html#aa2a51566bf37a09f7b7319d4bca51d4a',1,'tencent::av::AudioFrame::data_size()'],['../structtencent_1_1av_1_1_video_frame.html#a5d39e23f86196b64079f2b641340fbf7',1,'tencent::av::VideoFrame::data_size()']]],
  ['decode_5fcount',['decode_count',['../namespacetencent_1_1av.html#a6d48380ed8783aea2628545ceeb43d3c',1,'tencent::av::VideoStatParam']]],
  ['decode_5fparams',['decode_params',['../namespacetencent_1_1av.html#a550fce4aef19e7374a92248fc0341906',1,'tencent::av::VideoStatParam']]],
  ['desc',['desc',['../structtencent_1_1av_1_1_audio_frame.html#af56da8e135aea2f562cca6ec4edab90d',1,'tencent::av::AudioFrame::desc()'],['../structtencent_1_1av_1_1_video_frame.html#a5371733030bf327c21c2135e5fe9f8cd',1,'tencent::av::VideoFrame::desc()']]],
  ['description',['description',['../structtencent_1_1av_1_1_a_v_device_1_1_info.html#a237e2b0203318d58313a0353e338f739',1,'tencent::av::AVDevice::Info']]],
  ['device_5fid',['device_id',['../classtencent_1_1av_1_1_a_v_support_video_preview.html#ad5a6a7e5d1dd5bebf835ede07f68eeb7',1,'tencent::av::AVSupportVideoPreview::PreviewParam::device_id()'],['../namespacetencent_1_1av.html#a4365829807b2466d8845fee5b89bb03d',1,'tencent::av::CameraInfo::device_id()']]]
];
