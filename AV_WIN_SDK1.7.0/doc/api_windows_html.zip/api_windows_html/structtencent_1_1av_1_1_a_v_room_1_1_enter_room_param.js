var structtencent_1_1av_1_1_a_v_room_1_1_enter_room_param =
[
    [ "room_type", "structtencent_1_1av_1_1_a_v_room_1_1_enter_room_param.html#afa870b8255d63fdf818d8a537a1954dc", null ]
];