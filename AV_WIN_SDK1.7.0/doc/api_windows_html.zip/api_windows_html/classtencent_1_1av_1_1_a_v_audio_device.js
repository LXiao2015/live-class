var classtencent_1_1av_1_1_a_v_audio_device =
[
    [ "FrameDataCallback", "classtencent_1_1av_1_1_a_v_audio_device.html#a1fb9f3f2a34f3ad0060f297f040061a5", null ],
    [ "GetDynamicVolume", "classtencent_1_1av_1_1_a_v_audio_device.html#abb6adad67c06beec858af81700bafe5e", null ],
    [ "GetFrameCustomData", "classtencent_1_1av_1_1_a_v_audio_device.html#aa5558bb48c1e65a83d8a90ecdfd72ecc", null ],
    [ "GetFrameDataCallback", "classtencent_1_1av_1_1_a_v_audio_device.html#a653050644f2a537cd3cccbc310b775a8", null ],
    [ "GetVolume", "classtencent_1_1av_1_1_a_v_audio_device.html#a3a7271c28b62520c81c7a6d3e338e3f1", null ],
    [ "SetFrameDataCallback", "classtencent_1_1av_1_1_a_v_audio_device.html#af789f4a745061ed17c64161d5c2c2b93", null ],
    [ "SetVolume", "classtencent_1_1av_1_1_a_v_audio_device.html#a2ad2785d495049d161791c183b8a0586", null ]
];