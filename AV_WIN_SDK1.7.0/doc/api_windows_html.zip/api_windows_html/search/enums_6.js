var searchData=
[
  ['relationtype',['RelationType',['../namespacetencent_1_1av.html#acec14806701ac8bb8c60f6daa6434c26',1,'tencent::av']]],
  ['roomtype',['RoomType',['../classtencent_1_1av_1_1_a_v_room.html#a7656ec1015b94f3f34dc3786af057e86',1,'tencent::av::AVRoom']]]
];
