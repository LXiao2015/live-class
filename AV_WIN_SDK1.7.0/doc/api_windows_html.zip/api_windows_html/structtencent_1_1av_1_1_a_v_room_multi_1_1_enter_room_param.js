var structtencent_1_1av_1_1_a_v_room_multi_1_1_enter_room_param =
[
    [ "EnterRoomParam", "structtencent_1_1av_1_1_a_v_room_multi_1_1_enter_room_param.html#a0da14e5d056d1515b16fb19da4c72feb", null ],
    [ "app_room_id", "structtencent_1_1av_1_1_a_v_room_multi_1_1_enter_room_param.html#ac592fc01210e184cf564d80366c17708", null ],
    [ "audio_category", "structtencent_1_1av_1_1_a_v_room_multi_1_1_enter_room_param.html#aad125ea61b97087b85837ad682c3831d", null ],
    [ "auth_bits", "structtencent_1_1av_1_1_a_v_room_multi_1_1_enter_room_param.html#a274827efe7c3795fea8e258a3e7c444c", null ],
    [ "auth_buffer", "structtencent_1_1av_1_1_a_v_room_multi_1_1_enter_room_param.html#a292f632ea2e85a3968f07f104423dbba", null ],
    [ "auto_create_room", "structtencent_1_1av_1_1_a_v_room_multi_1_1_enter_room_param.html#ac72d619366e48c1aaa9fd1dea2c5ab88", null ],
    [ "av_control_role", "structtencent_1_1av_1_1_a_v_room_multi_1_1_enter_room_param.html#afd6aba9eaf8e8e51d6c808a91c52b6b6", null ]
];