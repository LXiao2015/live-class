var structtencent_1_1av_1_1_video_frame =
[
    [ "VideoFrame", "structtencent_1_1av_1_1_video_frame.html#a7846baa8e039f59183cbad81f39dc0c7", null ],
    [ "data", "structtencent_1_1av_1_1_video_frame.html#a317c4b2b6627e49f52b891a9809c4b51", null ],
    [ "data_size", "structtencent_1_1av_1_1_video_frame.html#a5d39e23f86196b64079f2b641340fbf7", null ],
    [ "desc", "structtencent_1_1av_1_1_video_frame.html#a5371733030bf327c21c2135e5fe9f8cd", null ],
    [ "identifier", "structtencent_1_1av_1_1_video_frame.html#a0b172e6ba0751512678ed33734ad9a24", null ]
];