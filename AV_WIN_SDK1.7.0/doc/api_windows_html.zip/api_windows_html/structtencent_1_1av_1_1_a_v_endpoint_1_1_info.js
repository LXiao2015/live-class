var structtencent_1_1av_1_1_a_v_endpoint_1_1_info =
[
    [ "Info", "structtencent_1_1av_1_1_a_v_endpoint_1_1_info.html#a72f248bc08122ddc2943fb32ce6fdd30", null ],
    [ "~Info", "structtencent_1_1av_1_1_a_v_endpoint_1_1_info.html#a8fb019793533526f275723a70fb48da2", null ],
    [ "has_audio", "structtencent_1_1av_1_1_a_v_endpoint_1_1_info.html#a13b6a43e9acd9146b304f7173842df9c", null ],
    [ "has_camera_video", "structtencent_1_1av_1_1_a_v_endpoint_1_1_info.html#aa03776f58871a95748151cb545d3fa23", null ],
    [ "has_screen_video", "structtencent_1_1av_1_1_a_v_endpoint_1_1_info.html#acc244d64ec8bd25b340628751321ff31", null ],
    [ "identifier", "structtencent_1_1av_1_1_a_v_endpoint_1_1_info.html#a216fe1e010e9dff40c3b74ba701f3536", null ],
    [ "is_mute", "structtencent_1_1av_1_1_a_v_endpoint_1_1_info.html#acb3045d39d905bb76f4ac470b7644a04", null ],
    [ "sdk_version", "structtencent_1_1av_1_1_a_v_endpoint_1_1_info.html#a77567aea2c2179c1da35d6c9e0988c40", null ],
    [ "terminal_type", "structtencent_1_1av_1_1_a_v_endpoint_1_1_info.html#a9a1f4ee4e2fbea79cf2d52de51775e24", null ]
];