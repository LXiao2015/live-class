var classtencent_1_1av_1_1_a_v_accompany_device =
[
    [ "SourceType", "classtencent_1_1av_1_1_a_v_accompany_device.html#a47a759576a99c7a169bf4d0781b8ba59", [
      [ "AV_ACCOMPANY_SOURCE_TYPE_NONE", "classtencent_1_1av_1_1_a_v_accompany_device.html#a47a759576a99c7a169bf4d0781b8ba59a823c4154edfd4759bd384519e0e3c4fa", null ],
      [ "AV_ACCOMPANY_SOURCE_TYPE_SYSTEM", "classtencent_1_1av_1_1_a_v_accompany_device.html#a47a759576a99c7a169bf4d0781b8ba59a3bf2b8939bf5b37bf032758c40945c7d", null ],
      [ "ACCOMPANY_SOURCE_TYPE_PROCESS", "classtencent_1_1av_1_1_a_v_accompany_device.html#a47a759576a99c7a169bf4d0781b8ba59a7733afbd8f2250f6d33c603f691fdc8d", null ]
    ] ],
    [ "GetMediaFilePath", "classtencent_1_1av_1_1_a_v_accompany_device.html#a875cdfaae44a135615bbd28c732b9fe1", null ],
    [ "GetPlayerPath", "classtencent_1_1av_1_1_a_v_accompany_device.html#a4aeeda8afdad50eebe8257bea7fee688", null ],
    [ "GetSourceType", "classtencent_1_1av_1_1_a_v_accompany_device.html#ac7775d640bdd77dd3267fbeb1ccd8ea5", null ],
    [ "SetSource", "classtencent_1_1av_1_1_a_v_accompany_device.html#aac003ccfe6b359af540c6067487c2ec8", null ]
];