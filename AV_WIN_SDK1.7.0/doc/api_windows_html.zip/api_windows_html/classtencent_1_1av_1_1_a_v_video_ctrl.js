var classtencent_1_1av_1_1_a_v_video_ctrl =
[
    [ "~AVVideoCtrl", "classtencent_1_1av_1_1_a_v_video_ctrl.html#a92877e47a5d9118da0784b834cfd4c97", null ],
    [ "GetQualityTips", "classtencent_1_1av_1_1_a_v_video_ctrl.html#a750fa3c9f52f16e4469831dd2fa92ec8", null ],
    [ "SetExternalCapAbility", "classtencent_1_1av_1_1_a_v_video_ctrl.html#a09d5b7ec0b6d5809cf644180b0190f70", null ]
];