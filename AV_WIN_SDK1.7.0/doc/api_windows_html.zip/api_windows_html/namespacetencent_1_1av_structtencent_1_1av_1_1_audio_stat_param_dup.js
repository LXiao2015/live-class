var namespacetencent_1_1av_structtencent_1_1av_1_1_audio_stat_param_dup =
[
    [ "qos_param", "namespacetencent_1_1av.html#a9355d99a7b08d3fd062759a80669f440", null ]
];