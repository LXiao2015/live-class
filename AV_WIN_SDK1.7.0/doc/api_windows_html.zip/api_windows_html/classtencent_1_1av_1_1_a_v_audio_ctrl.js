var classtencent_1_1av_1_1_a_v_audio_ctrl =
[
    [ "AudioDataCallback", "classtencent_1_1av_1_1_a_v_audio_ctrl.html#a623bebe3b43e06b713cdb4db9b19c44a", null ],
    [ "AudioDataSourceType", "classtencent_1_1av_1_1_a_v_audio_ctrl.html#a5e984967b62feac65b9237b53e8eca68", [
      [ "AUDIO_DATA_SOURCE_MIC", "classtencent_1_1av_1_1_a_v_audio_ctrl.html#a5e984967b62feac65b9237b53e8eca68a467bd47cd055d4c47af4b4743dd2043b", null ],
      [ "AUDIO_DATA_SOURCE_MIXTOSEND", "classtencent_1_1av_1_1_a_v_audio_ctrl.html#a5e984967b62feac65b9237b53e8eca68a47609a7f26dff81ab413256a142cc2c1", null ],
      [ "AUDIO_DATA_SOURCE_SEND", "classtencent_1_1av_1_1_a_v_audio_ctrl.html#a5e984967b62feac65b9237b53e8eca68a6f0f61ada45c8fa37642ce93212b7135", null ],
      [ "AUDIO_DATA_SOURCE_MIXTOPLAY", "classtencent_1_1av_1_1_a_v_audio_ctrl.html#a5e984967b62feac65b9237b53e8eca68a9befdbd329a3f0b5fdfbaf5243b223ad", null ],
      [ "AUDIO_DATA_SOURCE_PLAY", "classtencent_1_1av_1_1_a_v_audio_ctrl.html#a5e984967b62feac65b9237b53e8eca68aed27105ce6b2361db9cdf087dc4641cd", null ],
      [ "AUDIO_DATA_SOURCE_NETSTREM", "classtencent_1_1av_1_1_a_v_audio_ctrl.html#a5e984967b62feac65b9237b53e8eca68a5736aa3c38da0ab761d8bc7ee3b3eb6a", null ],
      [ "AUDIO_DATA_SOURCE_END", "classtencent_1_1av_1_1_a_v_audio_ctrl.html#a5e984967b62feac65b9237b53e8eca68a2009bffade2c1b3679fde33c9061d10d", null ]
    ] ],
    [ "~AVAudioCtrl", "classtencent_1_1av_1_1_a_v_audio_ctrl.html#a811779de90b870a566497b2867058bc8", null ],
    [ "EnableAEC", "classtencent_1_1av_1_1_a_v_audio_ctrl.html#aa227b98b7ad3ec19696455d667200768", null ],
    [ "EnableBoost", "classtencent_1_1av_1_1_a_v_audio_ctrl.html#af4a833d46a0de08b9e5caf8889d2412f", null ],
    [ "EnableNS", "classtencent_1_1av_1_1_a_v_audio_ctrl.html#abccbdda8e1eb75916947866eb6acf648", null ],
    [ "GetAudioDataFormat", "classtencent_1_1av_1_1_a_v_audio_ctrl.html#a9fe507beb2da4b4dcffcd0c609cc80f4", null ],
    [ "GetAudioDataVolume", "classtencent_1_1av_1_1_a_v_audio_ctrl.html#ad0b80254749f68e5d4fb83930dddad4d", null ],
    [ "GetQualityTips", "classtencent_1_1av_1_1_a_v_audio_ctrl.html#ad7fcf30ad55347275dff7528d75f81f4", null ],
    [ "IsAECEnable", "classtencent_1_1av_1_1_a_v_audio_ctrl.html#aba36fe5815a999f720caa8dd9afbd4fb", null ],
    [ "IsBoostEnable", "classtencent_1_1av_1_1_a_v_audio_ctrl.html#a9db3e96b90f1818d3426b73d22a1bf17", null ],
    [ "IsNSEnable", "classtencent_1_1av_1_1_a_v_audio_ctrl.html#a89ac543d48ae73397e4df6f5704feb50", null ],
    [ "RegistAudioDataCallback", "classtencent_1_1av_1_1_a_v_audio_ctrl.html#af1666ad99f0f4fb52a005a76c2b36090", null ],
    [ "SetAudioDataFormat", "classtencent_1_1av_1_1_a_v_audio_ctrl.html#aefe1043fec1bcfefe02933001d1880c6", null ],
    [ "SetAudioDataVolume", "classtencent_1_1av_1_1_a_v_audio_ctrl.html#aad24a6cf6325575239615c9f28fb874a", null ],
    [ "UnregistAudioDataCallback", "classtencent_1_1av_1_1_a_v_audio_ctrl.html#a06223326332f52c79660160b9425e8ee", null ],
    [ "UnregistAudioDataCallbackAll", "classtencent_1_1av_1_1_a_v_audio_ctrl.html#afe5d30db1a173616dc04f4bfa15fff0e", null ]
];