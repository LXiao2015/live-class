var structtencent_1_1av_1_1_a_v_room_1_1_delegate =
[
    [ "~Delegate", "structtencent_1_1av_1_1_a_v_room_1_1_delegate.html#adecf5b371ea5ab56602d91f03fb126ad", null ],
    [ "OnEndpointsUpdateInfo", "structtencent_1_1av_1_1_a_v_room_1_1_delegate.html#a3e3b181d6d307edf3b2df2e334e4c97a", null ],
    [ "OnEnterRoomComplete", "structtencent_1_1av_1_1_a_v_room_1_1_delegate.html#a1bf7b6af97cd3cee8be3eafd466b4712", null ],
    [ "OnExitRoomComplete", "structtencent_1_1av_1_1_a_v_room_1_1_delegate.html#a827f57376285612cb63711a84839eae1", null ],
    [ "OnPrivilegeDiffNotify", "structtencent_1_1av_1_1_a_v_room_1_1_delegate.html#aac6b0759657f82751ffa1fd81e594bfc", null ]
];