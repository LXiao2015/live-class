var searchData=
[
  ['video_5fparam',['video_param',['../namespacetencent_1_1av.html#a568ef391cc4ba8aa60a94673642f22ff',1,'tencent::av::RoomStatParam']]],
  ['video_5fsrc_5ftype',['video_src_type',['../structtencent_1_1av_1_1_view.html#ab44b466129abc83aa1db89e592a014e3',1,'tencent::av::View']]],
  ['view_5ftype',['view_type',['../namespacetencent_1_1av.html#a993ceb389711655930286b762b64a39e',1,'tencent::av::VideoEncodeParam::view_type()'],['../namespacetencent_1_1av.html#af931b01eaedcba01ed2c0bba8d898026',1,'tencent::av::VideoDecodeParam::view_type()']]]
];
