var searchData=
[
  ['video_5fcodec_5ftype_5fh264',['VIDEO_CODEC_TYPE_H264',['../namespacetencent_1_1av.html#a282889528c810aacce2922f7a8993fcfa20c5b6034fb698d50b9508f8ce07996c',1,'tencent::av']]],
  ['video_5fsrc_5ftype_5fcamera',['VIDEO_SRC_TYPE_CAMERA',['../namespacetencent_1_1av.html#aeb6ba00210cf2e03eb544a9c62d7ef2cafbebc4fc95c5dbcc2f40c60cc5901eee',1,'tencent::av']]],
  ['video_5fsrc_5ftype_5fnone',['VIDEO_SRC_TYPE_NONE',['../namespacetencent_1_1av.html#aeb6ba00210cf2e03eb544a9c62d7ef2caeb8889602537184493a21bd4bae588b5',1,'tencent::av']]],
  ['video_5fsrc_5ftype_5fscreen',['VIDEO_SRC_TYPE_SCREEN',['../namespacetencent_1_1av.html#aeb6ba00210cf2e03eb544a9c62d7ef2ca9098ba2f3e6a96dcc2c4e968b46149a7',1,'tencent::av']]],
  ['view_5fsize_5ftype_5fbig',['VIEW_SIZE_TYPE_BIG',['../namespacetencent_1_1av.html#ae5e26e7b448439d883bf936e977aa6d9a4c8c7139b91de256791ce32a11b4de56',1,'tencent::av']]],
  ['view_5fsize_5ftype_5fsmall',['VIEW_SIZE_TYPE_SMALL',['../namespacetencent_1_1av.html#ae5e26e7b448439d883bf936e977aa6d9ad943ab21f6ded58e79b6a91ce32994d2',1,'tencent::av']]]
];
