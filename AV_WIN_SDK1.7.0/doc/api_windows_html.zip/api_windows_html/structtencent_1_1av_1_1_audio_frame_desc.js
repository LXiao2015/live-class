var structtencent_1_1av_1_1_audio_frame_desc =
[
    [ "AudioFrameDesc", "structtencent_1_1av_1_1_audio_frame_desc.html#ae539b3e53c4a179150217e132c359dd9", null ],
    [ "bits", "structtencent_1_1av_1_1_audio_frame_desc.html#a725cd18cf89834985b836437da543648", null ],
    [ "channel_num", "structtencent_1_1av_1_1_audio_frame_desc.html#ad1512e9674e60ed7b0f68cd49cda2211", null ],
    [ "sample_rate", "structtencent_1_1av_1_1_audio_frame_desc.html#af253a3182f15c0f47f9bce8e27318e4a", null ],
    [ "src_type", "structtencent_1_1av_1_1_audio_frame_desc.html#a2a5fcfb0f4ada2c16aa63ea4fa09dfda", null ]
];