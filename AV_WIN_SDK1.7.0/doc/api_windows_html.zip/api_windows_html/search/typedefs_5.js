var searchData=
[
  ['pretreatmentfun',['PreTreatmentFun',['../classtencent_1_1av_1_1_a_v_support_video_pre_treatment.html#a1d5c1ad89b75055318dea82e6c584596',1,'tencent::av::AVSupportVideoPreTreatment']]],
  ['previewcallback',['PreviewCallback',['../classtencent_1_1av_1_1_a_v_support_audio_preview.html#a7c1849ddbba1f391314ae4ab6e996192',1,'tencent::av::AVSupportAudioPreview::PreviewCallback()'],['../classtencent_1_1av_1_1_a_v_support_video_preview.html#aa0b74f3773d6da90c6a88b3efd7fb146',1,'tencent::av::AVSupportVideoPreview::PreviewCallback()']]]
];
