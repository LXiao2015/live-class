var searchData=
[
  ['oncaptureframe',['OnCaptureFrame',['../classtencent_1_1av_1_1_a_v_external_capture.html#ad1af57c9553a9226409dae3ee095fc1a',1,'tencent::av::AVExternalCapture']]],
  ['onendpointsupdateinfo',['OnEndpointsUpdateInfo',['../structtencent_1_1av_1_1_a_v_room_1_1_delegate.html#a3e3b181d6d307edf3b2df2e334e4c97a',1,'tencent::av::AVRoom::Delegate']]],
  ['onenterroomcomplete',['OnEnterRoomComplete',['../structtencent_1_1av_1_1_a_v_room_1_1_delegate.html#a1bf7b6af97cd3cee8be3eafd466b4712',1,'tencent::av::AVRoom::Delegate']]],
  ['onexitroomcomplete',['OnExitRoomComplete',['../structtencent_1_1av_1_1_a_v_room_1_1_delegate.html#a827f57376285612cb63711a84839eae1',1,'tencent::av::AVRoom::Delegate']]],
  ['onprivilegediffnotify',['OnPrivilegeDiffNotify',['../structtencent_1_1av_1_1_a_v_room_1_1_delegate.html#aac6b0759657f82751ffa1fd81e594bfc',1,'tencent::av::AVRoom::Delegate']]]
];
