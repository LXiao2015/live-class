var structtencent_1_1av_1_1_audio_frame =
[
    [ "AudioFrame", "structtencent_1_1av_1_1_audio_frame.html#a568672b2d98980d650472d99eaf84c46", null ],
    [ "data", "structtencent_1_1av_1_1_audio_frame.html#a7bac65e6cc7bbb07850610906f65578a", null ],
    [ "data_size", "structtencent_1_1av_1_1_audio_frame.html#aa2a51566bf37a09f7b7319d4bca51d4a", null ],
    [ "desc", "structtencent_1_1av_1_1_audio_frame.html#af56da8e135aea2f562cca6ec4edab90d", null ],
    [ "identifier", "structtencent_1_1av_1_1_audio_frame.html#a973c9faddad6f838a34a86414ab59555", null ]
];