var searchData=
[
  ['capture_5fparam',['capture_param',['../namespacetencent_1_1av.html#a42dd56a0b700470476d4bb45c500cf93',1,'tencent::av::VideoStatParam']]],
  ['channel_5fcount',['channel_count',['../namespacetencent_1_1av.html#acc3dd9a73f0244397c4a02120ebc5e08',1,'tencent::av::AudioQosParam']]],
  ['channel_5fnum',['channel_num',['../structtencent_1_1av_1_1_audio_frame_desc.html#ad1512e9674e60ed7b0f68cd49cda2211',1,'tencent::av::AudioFrameDesc']]],
  ['codec_5ftype',['codec_type',['../namespacetencent_1_1av.html#a1899649e7779565102bdfab1dd0779c9',1,'tencent::av::AudioQosParam']]],
  ['color_5fformat',['color_format',['../structtencent_1_1av_1_1_video_frame_desc.html#a67c7a52ec608d4fa4daa465476a39a07',1,'tencent::av::VideoFrameDesc::color_format()'],['../classtencent_1_1av_1_1_a_v_support_video_preview.html#a94e2c9f3be7d9ab84c337fef6bda05ff',1,'tencent::av::AVSupportVideoPreview::PreviewParam::color_format()']]],
  ['cpu_5frate_5fapp',['cpu_rate_app',['../namespacetencent_1_1av.html#aee1f10604c356bc8268d8253de30ae87',1,'tencent::av::NetworkStatParam']]],
  ['cpu_5frate_5fsys',['cpu_rate_sys',['../namespacetencent_1_1av.html#acf9930c64f033fdadb2e236e989182e3',1,'tencent::av::NetworkStatParam']]]
];
