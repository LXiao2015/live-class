var searchData=
[
  ['audioframe',['AudioFrame',['../structtencent_1_1av_1_1_audio_frame.html#a568672b2d98980d650472d99eaf84c46',1,'tencent::av::AudioFrame']]],
  ['audioframedesc',['AudioFrameDesc',['../structtencent_1_1av_1_1_audio_frame_desc.html#ae539b3e53c4a179150217e132c359dd9',1,'tencent::av::AudioFrameDesc']]]
];
