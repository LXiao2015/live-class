var searchData=
[
  ['framedatacallback',['FrameDataCallback',['../classtencent_1_1av_1_1_a_v_audio_device.html#a1fb9f3f2a34f3ad0060f297f040061a5',1,'tencent::av::AVAudioDevice::FrameDataCallback()'],['../classtencent_1_1av_1_1_a_v_video_device.html#ab32bae9a7dc346ce615bd4b4f2b76972',1,'tencent::av::AVVideoDevice::FrameDataCallback()']]]
];
