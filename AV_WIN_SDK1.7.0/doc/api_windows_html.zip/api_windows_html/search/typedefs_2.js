var searchData=
[
  ['devicechangecallback',['DeviceChangeCallback',['../classtencent_1_1av_1_1_a_v_device_mgr.html#a85631882e8686c9a4e527d1effde60cb',1,'tencent::av::AVDeviceMgr']]],
  ['deviceoperationcallback',['DeviceOperationCallback',['../classtencent_1_1av_1_1_a_v_device_mgr.html#a2afdf2237b1e3e160c1dd958fbdc9a94',1,'tencent::av::AVDeviceMgr::DeviceOperationCallback()'],['../classtencent_1_1av_1_1_a_v_device_test.html#a32576e53e7d1151c75bb204d1f846c95',1,'tencent::av::AVDeviceTest::DeviceOperationCallback()']]]
];
