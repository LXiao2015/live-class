var searchData=
[
  ['hasaudio',['HasAudio',['../classtencent_1_1av_1_1_a_v_endpoint.html#a3fcc93787527251232ab30f74850bd18',1,'tencent::av::AVEndpoint']]],
  ['hascameravideo',['HasCameraVideo',['../classtencent_1_1av_1_1_a_v_endpoint.html#ac094c68c32a24378098b53a67aed3e81',1,'tencent::av::AVEndpoint']]],
  ['hasscreenvideo',['HasScreenVideo',['../classtencent_1_1av_1_1_a_v_endpoint.html#af1c9d3de5c9d900d0f344f5c208000d5',1,'tencent::av::AVEndpoint']]]
];
