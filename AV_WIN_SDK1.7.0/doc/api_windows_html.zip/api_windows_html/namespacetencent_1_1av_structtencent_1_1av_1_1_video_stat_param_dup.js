var namespacetencent_1_1av_structtencent_1_1av_1_1_video_stat_param_dup =
[
    [ "capture_param", "namespacetencent_1_1av.html#a42dd56a0b700470476d4bb45c500cf93", null ],
    [ "decode_count", "namespacetencent_1_1av.html#a6d48380ed8783aea2628545ceeb43d3c", null ],
    [ "decode_params", "namespacetencent_1_1av.html#a550fce4aef19e7374a92248fc0341906", null ],
    [ "encode_count", "namespacetencent_1_1av.html#ab3ab566f7dd4174f65c63120be051ccd", null ],
    [ "encode_params", "namespacetencent_1_1av.html#a120fe310e388f364eac6410ecb566519", null ],
    [ "qos_param_big", "namespacetencent_1_1av.html#ae05abb95e5fd3d6fafe9442965586c3a", null ],
    [ "qos_param_small", "namespacetencent_1_1av.html#ab230c1dbd17a540379461a0b1bfb7236", null ]
];