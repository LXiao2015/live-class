var classtencent_1_1av_1_1_a_v_video_device =
[
    [ "FrameDataCallback", "classtencent_1_1av_1_1_a_v_video_device.html#ab32bae9a7dc346ce615bd4b4f2b76972", null ],
    [ "GetFrameCustomData", "classtencent_1_1av_1_1_a_v_video_device.html#a86105ae6a14e2ebee25d2231a1569698", null ],
    [ "GetFrameDataCallback", "classtencent_1_1av_1_1_a_v_video_device.html#aed5519201ce141b11849dd0b29c246f7", null ],
    [ "SetFrameDataCallback", "classtencent_1_1av_1_1_a_v_video_device.html#adf646104acbc204c9efa99f4ecc6749c", null ]
];