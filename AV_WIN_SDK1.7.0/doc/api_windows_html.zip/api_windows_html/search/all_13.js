var searchData=
[
  ['unregistaudiodatacallback',['UnregistAudioDataCallback',['../classtencent_1_1av_1_1_a_v_audio_ctrl.html#a06223326332f52c79660160b9425e8ee',1,'tencent::av::AVAudioCtrl']]],
  ['unregistaudiodatacallbackall',['UnregistAudioDataCallbackAll',['../classtencent_1_1av_1_1_a_v_audio_ctrl.html#afe5d30db1a173616dc04f4bfa15fff0e',1,'tencent::av::AVAudioCtrl']]]
];
