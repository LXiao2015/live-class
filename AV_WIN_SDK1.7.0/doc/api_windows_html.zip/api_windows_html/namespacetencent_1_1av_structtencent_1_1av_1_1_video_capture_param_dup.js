var namespacetencent_1_1av_structtencent_1_1av_1_1_video_capture_param_dup =
[
    [ "fps", "namespacetencent_1_1av.html#a721edd097559deba7ed9724dfc4b3b41", null ],
    [ "height", "namespacetencent_1_1av.html#ac0383defb85d465638403e88ac14720d", null ],
    [ "width", "namespacetencent_1_1av.html#a961061f1dffafe763fd10459715a88c5", null ]
];