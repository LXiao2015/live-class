var classtencent_1_1av_1_1_a_v_support_audio_preview =
[
    [ "PreviewCallback", "classtencent_1_1av_1_1_a_v_support_audio_preview.html#a7c1849ddbba1f391314ae4ab6e996192", null ],
    [ "GetPreviewCallback", "classtencent_1_1av_1_1_a_v_support_audio_preview.html#a13dbf3489171543f8eec09eb5d52e443", null ],
    [ "GetPreviewCustomData", "classtencent_1_1av_1_1_a_v_support_audio_preview.html#a212ee1bb1cea55e3e249c795cb20569f", null ],
    [ "SetPreviewCallback", "classtencent_1_1av_1_1_a_v_support_audio_preview.html#a0fe690f992f17708ac37d569bcdb412c", null ]
];